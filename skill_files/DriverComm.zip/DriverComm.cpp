// DriverComm.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include <stdio.h>
#include <stdlib.h>
#include "common.h"


/*
    Windows�ں���DeviceIoControl���������н��� 3������
*/
#include <windows.h>
#include <tchar.h>
#include <winioctl.h>
 
#define  MAX_LENGTH 1024
 
//===========================================================================
int CommDriver() {
    HANDLE  hFile = 0;
    BYTE    byBuf[0x20];
    BYTE    byBuf2[0x20];
    BOOL    bRet;
    DWORD   dwByteRead, i;
 
    //���豸
    hFile = CreateFileA( WIN32_LINK_NAME, GENERIC_READ | GENERIC_WRITE, 0, 0,
                        OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0  );
 
    if ( hFile == INVALID_HANDLE_VALUE ) {
        printf( "���豸������!\n" );
        return -1;
    }
 
    printf( "���豸�ɹ�!\n" );
 
    RtlFillMemory( byBuf, sizeof( byBuf ), '1' );
    bRet = DeviceIoControl( hFile, IOCTRL_HELLO_WORLD, byBuf, sizeof( byBuf ), \
                            byBuf2, sizeof( byBuf2 ), &dwByteRead, NULL );
 
    if ( bRet ) {
        printf( "HELLO_WORLD  ���ػ���������%d, ����:", dwByteRead );
        for ( i = 0; i < dwByteRead; i++ ) {
            printf( "%c", byBuf2[i] );
        }
        printf( "\n" );
    }
 
    RtlFillMemory( byBuf, sizeof( byBuf ), '2' );
 
    bRet = DeviceIoControl( hFile, IOCTRL_REC_FROM_APP, byBuf, sizeof( byBuf ),
                            byBuf2, sizeof( byBuf2 ), &dwByteRead, NULL );
 
    if ( bRet ) {
 
        printf( "REC_FROM_APP ���ػ���������%d, ����:", dwByteRead );
        for ( i = 0; i < dwByteRead; i++ ) {
            printf( "%c", byBuf2[i] );
        }
        printf( "\n" );
    }
 
    RtlFillMemory( byBuf, sizeof( byBuf ), '3' );
 
    bRet = DeviceIoControl( hFile, IOCTRL_SEND_TO_APP, byBuf, sizeof( byBuf ),
                            byBuf2, sizeof( byBuf2 ), &dwByteRead, NULL );
 
    if ( bRet ) {
        printf( "SEND_TO_APP  ���ػ���������%d, ����:", dwByteRead );
        for ( i = 0; i < dwByteRead; i++ ) {
            printf( "%c", byBuf2[i] );
        }
        printf( "\n" );
    }
 
    if ( hFile ) {
        CloseHandle( hFile );
    }
 
    return 0;
}


int main(int argc, char* argv[])
{
	CommDriver();
	system("pause");
	return 0;
}

